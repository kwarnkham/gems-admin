import{b as a,P as s}from"./index.59d8c18c.js";var u=a(async({router:o})=>{o.beforeEach((t,m,e)=>{const r=s.getItem("token");t.meta.requiresAuth&&!r?e({name:"login"}):e()})});export{u as default};
